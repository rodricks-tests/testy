# text-transform

Utilities for controlling the capitalization of text.

## Untitled

### Untitled

Use the uppercase utility to uppercase the text of an element:
The quick brown fox jumps over the lazy dog.
<p class="uppercase">The quick brown fox ...</p>

### Untitled

Use the lowercase utility to lowercase the text of an element:
The quick brown fox jumps over the lazy dog.
<p class="lowercase">The quick brown fox ...</p>

### Untitled

Use the capitalize utility to capitalize text of an element:
The quick brown fox jumps over the lazy dog.
<p class="capitalize">The quick brown fox ...</p>

### Untitled

Use the normal-case utility to preserve the original text casing of an element—typically used to reset capitalization at different breakpoints:
The quick brown fox jumps over the lazy dog.
<p class="normal-case">The quick brown fox ...</p>

### Untitled

Prefix a text-transform utility with a breakpoint variant like md: to only apply the utility at medium screen sizes and above:
<p class="capitalize md:uppercase ...">
Lorem ipsum dolor sit amet...
</p>
